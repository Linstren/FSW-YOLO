import ultralytics
#DW
model = ultralytics.YOLO('ultralytics/cfg/models/11PSAWT/11DWPSA2WT4.yaml')

print(model)


'''results = model.train(
    data='neu_yolov11(1)(1).yaml',
    epochs=60,
    batch=16,
    optimizer='SGD',
    lr0=0.01,
    iou=0.5,
    conf=0.25,
    momentum=0.937,
)'''