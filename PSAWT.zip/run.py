import torch
import torch.nn as nn

import torch
import torch.nn as nn

# 创建一个输入张量
x= torch.randn(2, 4, 2, 2)  # 输入张量的形状为 (batch_size, channels, height, width)
print("Input tensor shape:", x.shape)

m = x.shape[-1]

# 应用平均池化层
y =  torch.mean(x, dim=(2,3), keepdim=True)
print(m,x)
print("Output tensor shape:", y.shape,y)

'''n=y.repeat(1,1,m,m)
print("Output tensor shape:",n.shape)

z =x-y
print("Output tensor shape:",z.shape)'''
